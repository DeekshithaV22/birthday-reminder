import React from 'react';

const List = () => {
  return (
    <>
      <h2>list component</h2>
    </>
  );
};

export default List;
